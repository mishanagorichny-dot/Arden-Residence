# Builds ARDEN-home.html: the home page as one file with CSS, JS and its images embedded.
import re, base64, subprocess, os, tempfile
os.chdir(os.path.dirname(os.path.abspath(__file__)))
T = tempfile.mkdtemp()
h = open('index.html').read(); css = open('styles.css').read(); js = open('main.js').read()
ids = set(re.findall(r'assets/img/([\w-]+)\.jpg', h))
homes = dict(re.findall(r"id: '(\w+)',.*?img: '([\w-]+)'", js))
ids |= {homes[k] for k in ['birch', 'willow', 'oak']}                      # featured homes
amen = js[js.index('const AMEN'):js.index('];', js.index('const AMEN'))]
ids |= set(re.findall(r"img: '([\w-]+)'", amen)[:3])            # living teaser
ids.add(re.search(r"img\('([\w-]+)', 2000\)", js).group(1))     # register background
missing = [i for i in ids if not os.path.exists(f'assets/img/{i}.jpg')]
assert not missing, f'missing images: {missing}'
data = {}
for i in sorted(ids):
    out = f'{T}/{i}.jpg'
    mx = '1800' if i == '1600585154340-be6161a56a0c' else '1100'
    subprocess.run(['sips', '-Z', mx, '-s', 'formatOptions', '68', f'assets/img/{i}.jpg', '--out', out], capture_output=True)
    data[i] = 'data:image/jpeg;base64,' + base64.b64encode(open(out, 'rb').read()).decode()
for i, d in data.items():
    h = h.replace(f'assets/img/{i}.jpg', d)
embed = 'const EMBED = {' + ','.join(f'"{k}":"{v}"' for k, v in data.items()) + '};\n  const img = id => EMBED[id] || `assets/img/${id}.jpg`;'
js2 = js.replace("const img = id => `assets/img/${id}.jpg`;", embed)
h = h.replace('<link rel="stylesheet" href="styles.css?v=10">', '<style>\n' + css + '\n</style>').replace('<script src="main.js?v=10"></script>', '<script>\n' + js2 + '\n</script>')
open('ARDEN-home.html', 'w').write(h)
print(sorted(ids))
print(len(ids), 'images embedded,', round(len(h) / 1e6, 2), 'MB')
